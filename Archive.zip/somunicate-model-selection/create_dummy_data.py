import numpy as np
import pandas as pd


def create_dummy_dataset(
    n_folders, n_files_per_folder, output_filename="dummy_dataset.json"
):
    """
    Creates a dummy dataset in JSON format.

    Args:
        n_folders (int): Number of folders to simulate.
        n_files_per_folder (int): Number of files per folder to simulate.
        output_filename (str): Name of the JSON file to save the dataset to.
    """

    data = []
    target_list = [
        "having_finished_successfully",
        "having_a_problem",
        "process_ongoing",
        "being_ready",
        "having_news",
        "being_empty",
        "shutting_down",
        "negative_warnings",
        "urgency_reminder",
        "encouraging_confirmations",
        "starting_prompts",
        "waiting_prompts",
        "sophistication",
        "positivity",
        "progressiveness",
        "dominance",
        "solidity",
        "purity",
        "playfulness",
    ]

    for folder_idx in range(n_folders):
        for file_idx in range(n_files_per_folder):
            entry = {}
            entry["sound"] = f"/{folder_idx}/{file_idx}.mp3"

            # Timbre topics
            for i in range(16):
                entry[f"timbre_topic_{i}"] = np.random.rand()

            # Chroma topics
            for i in range(14):
                entry[f"chroma_topic_{i}"] = np.random.rand()

            # Loudness topics
            for i in range(8):
                entry[f"loudness_topic_{i}"] = np.random.rand()

            # Industry
            industries = [
                "Apps",
                "Consumer",
                "Future",
                "Health",
                "Home",
                "Mobility",
                "Os",
            ]
            chosen_industry = np.random.choice(industries)
            for industry in industries:
                entry[industry] = 1 if industry == chosen_industry else 0

            # Targets
            for target in target_list:
                entry[target] = np.random.uniform(-1, 1)

            data.append(entry)

    # Convert to DataFrame
    df = pd.DataFrame(data)

    # Save to JSON
    df.to_json(output_filename, orient="records", indent=4)

    print(f"Dummy dataset saved to {output_filename}")


if __name__ == "__main__":
    n_folders = 115
    n_files_per_folder = 7
    output_filename = "dummy_audio_dataset.json"

    create_dummy_dataset(n_folders, n_files_per_folder, output_filename)
